# Notification service

## install

```
npm install
```

## run project

```
npm run dev
```

```
SERVER : http://121.41.58.117:6006/api/v1/notification
LOCAL : http://localhost:6006/api/v1/notification
PORT : 6004
```

### read notification

##### URL : /read/:notifId

##### Method : GET

##

###

### All notification me

##### URL : /allme

##### Method : GET

##

###
