const app = require("../server").app;

module.exports = app;
